import React, { useState, useEffect } from "react";
import './App.css';
import Axios from 'axios'

const backend_url = 'http://localhost:3001'
function getStatus(dueDate_s) {
  //get dueDate in string format
  //compare the date difference with current date
  //return status
  const dueDate = new Date(dueDate_s);
  const currDate = new Date();
  //if we wanna count the dueDate as "overdue at the day after duedate"
  currDate.setHours(0, 0, 0, 0);
  const dateDifference = (dueDate-currDate)/(1000*60*60*24);
  if (dateDifference > 7)
  {
    return "Not urgent";
  }
  else if (dateDifference >= 0)
  {
    return "Due Soon";
  }
  else
  {
    return "Over due";
  }
}
function App() {

  const [taskName, setTaskName] = useState('')
  const [searchName, setSearchName] = useState('')
  const [description, setDescription] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [taskList, setTaskList] = useState([])

  const [newTaskName, setNewTaskName] = useState('')
  const [newDescription, setNewDescription]=useState('')
  const [newDueDate, setNewDueDate] = useState('')
  useEffect(()=> {
    Axios.get(backend_url+"/api/get").then((response)=>{
      setTaskList(response.data)
    })
  }, [])
  const submitTask = () => {
    //whenever a click on submit button, this function is called
    //create a post request to submit information to backend
    //get create date
    const d= new Date();
    var createDate = d.toISOString().split('T')[0];
    Axios.post(backend_url+"/api/insert", {
      taskName:taskName, 
      description: description, 
      dueDate: dueDate,
      createDate: createDate,
    });
    //after sending new task node to backend, refresh page
    document.location.reload();
  };

  const deleteTask = (taskid) => {
    Axios.delete(backend_url+"/api/delete/"+taskid);
    document.location.reload();
  };
  const updateTask = (taskid) => {
    Axios.put(backend_url+"/api/update/",{
      id: taskid,
      name: newTaskName,
      description: newDescription,
      dueDate: newDueDate,
    })
    //empty the text boxes
    setNewDescription("")
    setNewTaskName("")
    setNewDueDate("")
    document.location.reload();
  }
  const sortByDate = (is_sorting_by_due, is_ascending) => {
    //passing a flag to this function, 1 for sorting by due date, 0 for sorting by create date
    //ascending: earliest date to latest date
    var sortedList = taskList.slice();
    if (is_sorting_by_due)
    {
      //the dueDate value get from database is in string format, need to be changed to 
      sortedList = sortedList.sort((a, b) => Date.parse(b.dueDate) - Date.parse(a.dueDate));
    }
    else
    {
      sortedList = sortedList.sort((a, b) => Date.parse(b.createDate) - Date.parse(a.createDate));
    }
    if (is_ascending)
    {
      sortedList.reverse();
    }
    setTaskList(sortedList);
  };
  const searchList = (key, value) => {
    //key: on which to search such as id, taskName, dueDate etc.
    //value: the key's specific value to be searched
    //this is can be extended to other search feature in future development
    Axios.get(backend_url+"/api/search/"+key+"/"+value).then((response)=>{
      setTaskList(response.data)
    })
  };

  return (
    <div className="App">
      <h1>Hayden Ye: CheckBox task</h1>
      create a task
      <div className="task">
        <label>Name</label> 
        <input type="text" name="name" onChange= {(e)=>{
          setTaskName(e.target.value)
        }}/> 
        <label>Description</label>
        <input type="text" name="description" onChange= {(e)=>{
          setDescription(e.target.value)
        }}/>
        <label>Due date</label>
        <input type="text" name="dueDate" onChange= {(e)=>{
          setDueDate(e.target.value)
        }}/>
      </div>
      <button onClick={submitTask}>
        Create
      </button>
      <p>
        sort by due date:
        <button onClick={()=>{sortByDate(1,1)}}>
          Ascending
        </button>
        <button onClick={()=>{sortByDate(1,0)}}>
          descending
        </button>
      </p>
      <p>
        sort by create date:
        <button onClick={()=>{sortByDate(0,1)}}>
          Ascending
        </button>
        <button onClick={()=>{sortByDate(0,0)}}>
          descending
        </button>
      </p>
      <p>
        search by name:
        <input type="text" name="name" onChange= {(e)=>{
          setSearchName(e.target.value)
        }}/>
        <button onClick={()=>{searchList("taskName",searchName)}}>
          Search
        </button>
      </p>
      {taskList.map((val)=>{
        return (
          <div className="taskCard">
            <h1>{val.id+". "+val.taskName}</h1>
            <p>{"create date: "+val.createDate.split('T')[0]}</p>
            <p>{"task description: "+val.description}</p>
            <p>{"due date: "+val.dueDate.split('T')[0]}</p>
            <p>{"status: "+ getStatus(val.dueDate)}</p>
            <button onClick={()=>{deleteTask(val.id)}}>Delete</button>
            <p>{"name"}
              <input type="text" id="updateInput" onChange={(e)=>{
                setNewTaskName(e.target.value)
              }}/>
            </p>
            <p>{"description"}
              <input type="text" id="updateInput" onChange={(e)=>{
                setNewDescription(e.target.value)
              }}/>
            </p>
            <p>{"due date"}
              <input type="text" id="updateInput" onChange={(e)=>{
                setNewDueDate(e.target.value)
              }}/>
              </p>
            <button onClick={()=>{updateTask(val.id)}}> Update</button>
          </div>
          );
      })}
    </div>
  );
}

export default App;
